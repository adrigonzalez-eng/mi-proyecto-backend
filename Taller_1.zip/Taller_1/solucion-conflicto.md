# solucion del conflicto

*El archivo en conflicto era README.md.txt.
*Se crea una rama con el nombre de feature/conflicto
*Desde la rama "feature/conflicto" : contenia el texto "cambio desde la rama conflicto"
*Desde la rama "adriana" : contenia el texto "cambio desde la rama adriana"
*Haciendo el merge de las ramas presentro conflicto
*Se edito manualmente para solucionar el conflicto y unificar los cambios
*Se guarda el archivo en conflicto, se hizo git add . para mover los cambios y luego git commit -m 
*Despues se hizo  el merge de las ramas y la fusion
*Se soluciona el conflicto

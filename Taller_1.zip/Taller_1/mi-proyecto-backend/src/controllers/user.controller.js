
// Autor: Fanny González

let name = "Adriana Gonzalez";
let age = 37;
let country = "Colombia";

print(`Mi nombre es ${name}, tengo ${age} años y soy de ${country}`);